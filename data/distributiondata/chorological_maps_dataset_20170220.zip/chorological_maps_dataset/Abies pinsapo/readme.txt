CHOROLOGICAL MAP OF ABIES PINSAPO

Shapefiles:
Abies_pinsapo_marocana_plg.shp: Abies pinsapo subsp. marocana native ranges (polygon)
Abies_pinsapo_marocana_pnt.shp: Abies pinsapo subsp. marocana isolated populations (point)
Abies_pinsapo_pinsapo_plg.shp: Abies pinsapo subsp. pinsapo native ranges (polygon)
Abies_pinsapo_pinsapo_pnt.shp: Abies pinsapo subsp. pinsapo isolated populations (point)

Example of usage:
https://commons.wikimedia.org/wiki/File:Abies_pinsapo_range.svg

Copyright:
Creative Commons Attribution 4.0 International
https://creativecommons.org/licenses/by/4.0/deed.en

Please cite as:
Caudullo, G., Welk, E., San-Miguel-Ayanz, J., 2017. Chorological maps for the main European woody species. Data in Brief, X(X), xx-xx. DOI: 10.1016/j.dib.2016.XX.xxx

last update: 06 Oct 2016