CHOROLOGICAL MAP OF ACER CAMPESTRE

Shapefiles:
Acer_campestre_plg.shp: Acer campestre native ranges (polygon)
Acer_campestre_pnt.shp: Acer campestre isolated populations (point)
Acer_campestre_syn_pnt.shp: introduced and naturalized, synanthropic (point)

Example of usage:
https://commons.wikimedia.org/wiki/File:Acer_campestre_range.svg

Copyright:
Creative Commons Attribution 4.0 International
https://creativecommons.org/licenses/by/4.0/deed.en

Please cite as:
Caudullo, G., Welk, E., San-Miguel-Ayanz, J., 2017. Chorological maps for the main European woody species. Data in Brief, X(X), xx-xx. DOI: 10.1016/j.dib.2016.XX.xxx

last update: 10 Oct 2016