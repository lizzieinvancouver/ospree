CHOROLOGICAL MAP OF AESCULUS HIPPOCASTANUM

Shapefiles:
Aesculus_hippocastanum_plg.shp: Aesculus hippocastanum native ranges (polygon)
Aesculus_hippocastanum_pnt.shp: Aesculus hippocastanum isolated populations (point)

Example of usage:
https://commons.wikimedia.org/wiki/File:Aesculus_hippocastanum_range.svg

Copyright:
Creative Commons Attribution 4.0 International
https://creativecommons.org/licenses/by/4.0/deed.en

Please cite as:
Caudullo, G., Welk, E., San-Miguel-Ayanz, J., 2017. Chorological maps for the main European woody species. Data in Brief, X(X), xx-xx. DOI: 10.1016/j.dib.2016.XX.xxx

last update: 25 Aug 2016