CHOROLOGICAL MAP OF CASTANEA SATIVA

Shapefiles:
Castanea_sativa_plg.shp: Castanea sativa native ranges (polygon)
Castanea_sativa_pnt.shp: Castanea sativa isolated populations (point)
Castanea_sativa_syn_plg.shp: introduced and naturalized, synanthropic (polygon)
Castanea_sativa_syn_pnt.shp: introduced and naturalized, synanthropic (point)

Example of usage:
https://commons.wikimedia.org/wiki/File:Castanea_sativa_range.svg

Copyright:
Creative Commons Attribution 4.0 International
https://creativecommons.org/licenses/by/4.0/deed.en

Please cite as:
Caudullo, G., Welk, E., San-Miguel-Ayanz, J., 2017. Chorological maps for the main European woody species. Data in Brief, X(X), xx-xx. DOI: 10.1016/j.dib.2016.XX.xxx

last update: 02 Dec 2016