CHOROLOGICAL MAP OF CORNUS MAS

Shapefiles:
Cornus_mas_plg.shp: Cornus mas native ranges (polygon)
Cornus_mas_pnt.shp: Cornus mas isolated populations (point)
Cornus_mas_syn_pnt.shp: introduced and naturalized, synanthropic (point)

Example of usage:
https://commons.wikimedia.org/wiki/File:Cornus_mas_range.svg

Copyright:
Creative Commons Attribution 4.0 International
https://creativecommons.org/licenses/by/4.0/deed.en

Please cite as:
Caudullo, G., Welk, E., San-Miguel-Ayanz, J., 2017. Chorological maps for the main European woody species. Data in Brief, X(X), xx-xx. DOI: 10.1016/j.dib.2016.XX.xxx

last update: 10 Oct 2016