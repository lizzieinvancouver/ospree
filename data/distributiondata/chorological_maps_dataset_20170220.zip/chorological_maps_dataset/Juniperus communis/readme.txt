CHOROLOGICAL MAP OF JUNIPERUS COMMUNIS

Shapefiles:
Juniperus_communis_plg.shp: Juniperus communis native ranges (polygon)
Juniperus_communis_pnt.shp: Juniperus communis isolated populations (point)

Example of usage:
https://commons.wikimedia.org/wiki/File:Juniperus_communis_range.svg

Copyright:
Creative Commons Attribution 4.0 International
https://creativecommons.org/licenses/by/4.0/deed.en

Please cite as:
Caudullo, G., Welk, E., San-Miguel-Ayanz, J., 2017. Chorological maps for the main European woody species. Data in Brief, X(X), xx-xx. DOI: 10.1016/j.dib.2016.XX.xxx

last update: 06 Dec 2016