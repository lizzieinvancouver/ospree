CHOROLOGICAL MAP OF LARIX DECIDUA

Shapefiles:
Larix_decidua_carpatica_plg.shp: Larix decidua subsp. carpatica native ranges (polygon)
Larix_decidua_carpatica_pnt.shp: Larix decidua subsp. carpatica isolated populations (point)
Larix_decidua_decidua_plg.shp: Larix decidua subsp. decidua native ranges (polygon)
Larix_decidua_polonica_pnt.shp: Larix decidua subsp. polonica isolated populations (point)

Example of usage:
https://commons.wikimedia.org/wiki/File:Larix_decidua_range.svg

Copyright:
Creative Commons Attribution 4.0 International
https://creativecommons.org/licenses/by/4.0/deed.en

Please cite as:
Caudullo, G., Welk, E., San-Miguel-Ayanz, J., 2017. Chorological maps for the main European woody species. Data in Brief, X(X), xx-xx. DOI: 10.1016/j.dib.2016.XX.xxx

last update: 06 Oct 2016