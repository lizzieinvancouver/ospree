CHOROLOGICAL MAP OF PINUS MUGO

Shapefiles:
Pinus_mugo_mugo_rotundata_plg.shp: Pinus mugo native ranges (polygon)
Pinus_mugo_mugo_rotundata_pnt.shp: Pinus mugo isolated populations (point)
Pinus_mugo_uncinata_plg.shp: Pinus mugo subsp. uncinata native ranges (polygon)
Pinus_mugo_uncinata_pnt.shp: Pinus mugo subsp. uncinata isolated populations (point)

Example of usage:
https://commons.wikimedia.org/wiki/File:Pinus_mugo_range.svg

Copyright:
Creative Commons Attribution 4.0 International
https://creativecommons.org/licenses/by/4.0/deed.en

Please cite as:
Caudullo, G., Welk, E., San-Miguel-Ayanz, J., 2017. Chorological maps for the main European woody species. Data in Brief, X(X), xx-xx. DOI: 10.1016/j.dib.2016.XX.xxx

last update: 06 Oct 2016