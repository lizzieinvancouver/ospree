CHOROLOGICAL MAP OF QUERCUS PYRENAICA

Shapefiles:
Quercus_pyrenaica_plg.shp: Quercus pyrenaica native ranges (polygon)
Quercus_pyrenaica_pnt.shp: Quercus pyrenaica isolated populations (point)

Example of usage:
https://commons.wikimedia.org/wiki/File:Quercus_pyrenaica_range.svg

Copyright:
Creative Commons Attribution 4.0 International
https://creativecommons.org/licenses/by/4.0/deed.en

Please cite as:
Caudullo, G., Welk, E., San-Miguel-Ayanz, J., 2017. Chorological maps for the main European woody species. Data in Brief, X(X), xx-xx. DOI: 10.1016/j.dib.2016.XX.xxx

last update: 22 Sep 2016