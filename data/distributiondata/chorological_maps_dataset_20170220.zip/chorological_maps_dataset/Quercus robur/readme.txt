CHOROLOGICAL MAP OF QUERCUS ROBUR

Shapefiles:
Quercus_robur_plg.shp: Quercus robur native ranges (polygon)
Quercus_robur_pnt.shp: Quercus robur isolated populations (point)
Quercus_robur_syn_pnt.shp: introduced and naturalized, synanthropic (point)

Example of usage:
https://commons.wikimedia.org/wiki/File:Quercus_robur_range.svg

Copyright:
Creative Commons Attribution 4.0 International
https://creativecommons.org/licenses/by/4.0/deed.en

Please cite as:
Caudullo, G., Welk, E., San-Miguel-Ayanz, J., 2017. Chorological maps for the main European woody species. Data in Brief, X(X), xx-xx. DOI: 10.1016/j.dib.2016.XX.xxx

last update: 10 Oct 2016