CHOROLOGICAL MAP OF QUERCUS TROJANA

Shapefiles:
Quercus_trojana_euboica_pnt.shp: Quercus trojana subsp. euboica isolated populations (point)
Quercus_trojana_trojana_plg.shp: Quercus trojana subsp. trojana native ranges (polygon)
Quercus_trojana_trojana_pnt.shp: Quercus trojana subsp. trojana isolated populations (point)
Quercus_trojana_yaltirikii_pnt.shp: Quercus trojana subsp. yaltirikii isolated populations (point)

Example of usage:
https://commons.wikimedia.org/wiki/File:Quercus_trojana_range.svg

Copyright:
Creative Commons Attribution 4.0 International
https://creativecommons.org/licenses/by/4.0/deed.en

Please cite as:
Caudullo, G., Welk, E., San-Miguel-Ayanz, J., 2017. Chorological maps for the main European woody species. Data in Brief, X(X), xx-xx. DOI: 10.1016/j.dib.2016.XX.xxx

last update: 12 Oct 2016