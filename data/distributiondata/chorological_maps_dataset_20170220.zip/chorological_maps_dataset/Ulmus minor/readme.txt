CHOROLOGICAL MAP OF ULMUS MINOR

Shapefiles:
Ulmus_minor_plg.shp: Ulmus minor native ranges (polygon)
Ulmus_minor_pnt.shp: Ulmus minor isolated populations (point)
Ulmus_minor_syn_pnt.shp: introduced and naturalized, synanthropic (point)

Example of usage:
https://commons.wikimedia.org/wiki/File:Ulmus_minor_range.svg

Copyright:
Creative Commons Attribution 4.0 International
https://creativecommons.org/licenses/by/4.0/deed.en

Please cite as:
Caudullo, G., Welk, E., San-Miguel-Ayanz, J., 2017. Chorological maps for the main European woody species. Data in Brief, X(X), xx-xx. DOI: 10.1016/j.dib.2016.XX.xxx

last update: 10 Oct 2016